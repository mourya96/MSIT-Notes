int_val = 1
float_val = 1.1
string_val = 'MSIT'
bool_val = True

print("Integer: Type", type(int_val), "Value =", int_val)
print("Float: Type", type(float_val), "Value =", float_val)
print("String: Type", type(string_val), "Value =", string_val)
print("Boolean: Type", type(bool_val), "Value =", bool_val)

print("Integer to Float:", float(int_val))
print("Float to Integer:", int(float_val))
print("Float to String:", str(float_val))